# Book Management System

A full-stack web application for managing books with user authentication.

## Features

- User authentication (register, login, logout)
- Full CRUD operations for books
- Responsive design with Bootstrap
- Client-side form validation
- Title field is not editable once a book is created
- User's favorite author displayed in the top-right corner when logged in

## Schema Models

### User
- username
- password (handled by Passport)
- favoriteAuthor
- membershipDate (auto-generated)

### Book
- title
- author
- genre
- publishedDate
- rating (1-5)
- review
- owner (reference to User)

## Routes

### Authentication
- GET/POST /register
- GET/POST /login
- GET /logout

### Books
- GET /books - List all books
- GET /book/new - Form to create a new book
- POST /book - Create a new book
- GET /books/:id - View book details
- GET /books/:id/edit - Form to edit a book
- PUT /books/:id - Update a book
- DELETE /books/:id - Delete a book

## Getting Started

1. Install dependencies:
   ```
   npm install
   ```

2. Start MongoDB on your local machine

3. Start the application:
   ```
   npm start
   ```

4. Visit `http://localhost:3000` in your browser

## Technologies Used

- Node.js
- Express
- MongoDB with Mongoose
- EJS templates
- Bootstrap for styling and validation
- Passport.js for authentication 