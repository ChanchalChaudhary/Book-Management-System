const express = require('express');
const router = express.Router();
const passport = require('passport');
const User = require('../models/user');

// Middleware to check if user is authenticated
const isLoggedIn = (req, res, next) => {
  if (!req.isAuthenticated()) {
    return res.redirect('/login');
  }
  next();
};

// Register routes
router.get('/register', (req, res) => {
  res.render('users/register');
});

router.post('/register', async (req, res) => {
  try {
    const { username, password, favoriteAuthor } = req.body;
    const user = new User({ username, favoriteAuthor });
    const registeredUser = await User.register(user, password);
    req.login(registeredUser, err => {
      if (err) return next(err);
      res.redirect('/books');
    });
  } catch (e) {
    console.log(e);
    res.redirect('/register');
  }
});

// Login routes
router.get('/login', (req, res) => {
  res.render('users/login');
});

router.post('/login', passport.authenticate('local', { 
  failureRedirect: '/login',
  failureFlash: false
}), (req, res) => {
  res.redirect('/books');
});

// Logout route
router.get('/logout', (req, res, next) => {
  req.logout(function(err) {
    if (err) { return next(err); }
    res.redirect('/login');
  });
});

module.exports = router; 