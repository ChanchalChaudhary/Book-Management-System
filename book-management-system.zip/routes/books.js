const express = require('express');
const router = express.Router();
const Book = require('../models/book');

// Middleware to check if user is authenticated
const isLoggedIn = (req, res, next) => {
  if (!req.isAuthenticated()) {
    return res.redirect('/login');
  }
  next();
};

// GET /books - Index route
router.get('/', async (req, res) => {
  const books = await Book.find({});
  res.render('books/index', { books });
});

// GET /book/new - New book form
router.get('/new', isLoggedIn, (req, res) => {
  res.render('books/new');
});

// POST /book - Create new book
router.post('/', isLoggedIn, async (req, res) => {
  const book = new Book(req.body.book);
  book.owner = req.user._id;
  await book.save();
  res.redirect(`/books/${book._id}`);
});

// GET /books/:id - Show book details
router.get('/:id', async (req, res) => {
  const book = await Book.findById(req.params.id).populate('owner');
  if (!book) {
    return res.redirect('/books');
  }
  res.render('books/show', { book });
});

// GET /books/:id/edit - Edit book form
router.get('/:id/edit', isLoggedIn, async (req, res) => {
  const book = await Book.findById(req.params.id);
  if (!book) {
    return res.redirect('/books');
  }
  res.render('books/edit', { book });
});

// PUT /books/:id - Update book
router.put('/:id', isLoggedIn, async (req, res) => {
  const { id } = req.params;
  // Preserve the original title as it should not be editable
  const originalBook = await Book.findById(id);
  req.body.book.title = originalBook.title;
  
  await Book.findByIdAndUpdate(id, { ...req.body.book });
  res.redirect(`/books/${id}`);
});

// DELETE /books/:id - Delete book
router.delete('/:id', isLoggedIn, async (req, res) => {
  const { id } = req.params;
  await Book.findByIdAndDelete(id);
  res.redirect('/books');
});

module.exports = router; 