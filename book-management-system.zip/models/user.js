const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const passportLocalMongoose = require('passport-local-mongoose');

const UserSchema = new Schema({
  favoriteAuthor: {
    type: String,
    required: true
  },
  membershipDate: {
    type: Date,
    default: Date.now
  }
});

// Add username and password (passport-local-mongoose handles this)
UserSchema.plugin(passportLocalMongoose);

module.exports = mongoose.model('User', UserSchema); 